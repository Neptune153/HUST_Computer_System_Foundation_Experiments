#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

#define STUDENTS_NUM  10

typedef struct temp {
	char  sname[8];
	char  sid[11];    //  ��U202315123
	short  scores[8]; //  8�ſεķ���
	short  average;   //  ƽ����
}student;

void display(student* s, int num);
void initStudents(student* s,int num)
{
	strcpy(s[0].sname, "xuxy");
	strcpy(s[0].sid, "U202315001");
	s[0].scores[0] = 95;
	s[0].scores[1] = 85;
	s[0].scores[2] = 90;
	for (int i=1;i<8;i++)
	   s[0].scores[i] = 80+i;
	s[0].average = 0;

	strcpy(s[1].sname, "wang");
	strcpy(s[1].sid, "U202315002");
	s[1].scores[0] = 100;
}

void computeAverageScore(student* s,int num)
{

}

int main()
{
	student s[STUDENTS_NUM];
	int start, finish, duration;

	printf("%d\n", sizeof(student));
	initStudents(s, STUDENTS_NUM);         // ��ʼ��ѧ����Ϣ
	display(s, STUDENTS_NUM);
	start = GetTickCount();  // ͷ�ļ�windows.h���õ�����ϵͳ���е�ʱ�� ��ȷ�����룬
	computeAverageScore(s, STUDENTS_NUM);
	finish = GetTickCount();
	duration = finish - start;
	printf("����ƽ���ɼ���ʱ�� %d  ����\n", duration);

	return 0;
}

